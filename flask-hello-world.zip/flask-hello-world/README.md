# flask-hello-world



## Objetivo desse projeto

Apresentar a estrutura básica de um projeto Flask para execução de pipeline